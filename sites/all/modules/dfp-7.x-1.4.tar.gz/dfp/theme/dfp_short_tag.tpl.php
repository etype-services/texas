<?php
  /**
   * @file
   * Default template for dfp short tags.
   */
?>

<a href="<?php print $url_jump; ?>">
  <img src="<?php print $url_ad; ?>">
</a>
